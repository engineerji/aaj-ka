package Servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import service.ValidateTech;


public class ValidateServlet extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		PrintWriter out = resp.getWriter();
		
		String technology=req.getParameter("tech");
		String city=req.getParameter("city");
		ValidateTech validate=new ValidateTech();
		String result=validate.isValid(technology);
		if(result.equals("invalid")) {
			out.println("<h2 style='color:red;'>Invalid Technology</h2></br>");
			out.print("<a href='FindJob.html'>Enter Valid Technology</a>");
		}
		else {
			req.setAttribute("re", result);
			req.setAttribute("city", city);
			req.getRequestDispatcher("FilterJobs").forward(req, resp);;
		}
		
	}
	

}
