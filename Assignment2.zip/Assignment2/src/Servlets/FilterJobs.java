package Servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import service.JobService;


public class FilterJobs extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		PrintWriter out = resp.getWriter();
		String technology = (String)req.getAttribute("re");
		out.print(technology);
		String city=(String)req.getAttribute("city");
		out.print(city);
		JobService jobs= new JobService();
		List<String> list= jobs.getJobList(technology, city);
		for(String st:list) {
			out.println(st+"");		
		}
		req.setAttribute("joblist", list);
		req.getRequestDispatcher("ResponseServlet").forward(req, resp);
	}
	

}
