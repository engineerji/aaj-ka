package Servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ResponseServlet
 */
public class ResponseServlet extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		List<String> jobList=(List<String>)req.getAttribute("joblist");
		PrintWriter out =resp.getWriter();
		out.println("<h2>JobList</h2></br>");
		out.println("<table>");
		for(String job:jobList) {
			out.println("<tr>");
			out.println("<td>");
			out.print("<h3>"+job+"</h3>");
			out.println("</td>");
			out.println("</tr>");
		}
		out.println("</table>");
	}
	

}
