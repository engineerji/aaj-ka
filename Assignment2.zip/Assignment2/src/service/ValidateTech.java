package service;

public class ValidateTech {
	
	String[] techs= {"Java","Angular","Python","R","nodejs","Selenium",".Net"};
	
	public String isValid(String tech) {
		for(String techn:techs) {
			if(techn.equalsIgnoreCase(tech)) {
				return techn;
			}
		}
		return "invalid";
	}
}
